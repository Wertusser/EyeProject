# -*- coding: utf-8 -*-

__author__ = 'George George'
__version__ = '1.0'
__email__ = 'wertusser@gmail.com'
__contact__ = 'https://vk.com/id247225570'

from .infoVk import *
from .transliter import *
